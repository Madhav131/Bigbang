export const BASE_URL = 'https://theapplified.com/bigbang/api/v1/';
export const ACCEPT_HEADER = 'application/x.bigbang.v1+json';
